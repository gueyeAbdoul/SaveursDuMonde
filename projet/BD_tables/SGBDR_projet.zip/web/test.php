public function creerRecette($name, $description, $imgName, $ingredients, $tags) {
    // Ajout de la recette dans la table Recette
    $query = 'INSERT INTO recette(title, description, photo) VALUES (:title, :description, :photo)';
    $params = [
        'title' => htmlspecialchars($name),
        'description' => htmlspecialchars($description),
        'photo' => $imgName
    ];
    $this->exec($query, $params);
    $recette_id = $this->pdo->lastInsertId();

    // Ajout des ingrédients dans la table Ingredient et la table Ingredient_Recette
    foreach ($ingredients as $ingredient) {
        // Ajout de l'ingrédient dans la table Ingredient
        $query = 'INSERT INTO ingredient(name, image) VALUES (:name, :image)';
        $params = [
            'name' => htmlspecialchars($ingredient['name']),
            'image' => htmlspecialchars($ingredient['image'])
        ];
        $this->exec($query, $params);
        $ingredient_id = $this->pdo->lastInsertId();

        // Ajout de la relation entre l'ingrédient et la recette dans la table Ingredient_Recette
        $query = 'INSERT INTO ingredient_recette(ingredient_id, recette_id) VALUES (:ingredient_id, :recette_id)';
        $params = [
            'ingredient_id' => $ingredient_id,
            'recette_id' => $recette_id
        ];
        $this->exec($query, $params);
    }

    // Ajout des tags dans la table Tag et la table Tag_Recette
    foreach ($tags as $tag) {
        // Ajout du tag dans la table Tag
        $query = 'INSERT INTO tag(name, picture) VALUES (:name, :picture)';
        $params = [
            'name' => htmlspecialchars($tag['name']),
            'picture' => htmlspecialchars($tag['picture'])
        ];
        $this->exec($query, $params);
        $tag_id = $this->pdo->lastInsertId();

        // Ajout de la relation entre le tag et la recette dans la table Tag_Recette
        $query = 'INSERT INTO tag_recette(tag_id, recette_id) VALUES (:tag_id, :recette_id)';
        $params = [
            'tag_id' => $tag_id,
            'recette_id' => $recette_id
        ];
        $this->exec($query, $params);
    }
}
